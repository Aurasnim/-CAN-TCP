Middlewares/LwIP/Core/def.o: \
 C:/Users/Sasha/STM32Cube/Repository/STM32Cube_FW_F2_V1.9.5/Middlewares/Third_Party/LwIP/src/core/def.c \
 ../../../../../../../../Middlewares/Third_Party/LwIP/src/include/lwip/opt.h \
 ../../../Inc/lwipopts.h \
 ../../../../../../../../Middlewares/Third_Party/LwIP/src/include/lwip/debug.h \
 ../../../../../../../../Middlewares/Third_Party/LwIP/src/include/lwip/arch.h \
 ../../../../../../../../Middlewares/Third_Party/LwIP/system/arch/cc.h \
 ../../../../../../../../Middlewares/Third_Party/LwIP/system/arch/cpu.h \
 ../../../../../../../../Middlewares/Third_Party/LwIP/src/include/lwip/def.h
../../../../../../../../Middlewares/Third_Party/LwIP/src/include/lwip/opt.h:
../../../Inc/lwipopts.h:
../../../../../../../../Middlewares/Third_Party/LwIP/src/include/lwip/debug.h:
../../../../../../../../Middlewares/Third_Party/LwIP/src/include/lwip/arch.h:
../../../../../../../../Middlewares/Third_Party/LwIP/system/arch/cc.h:
../../../../../../../../Middlewares/Third_Party/LwIP/system/arch/cpu.h:
../../../../../../../../Middlewares/Third_Party/LwIP/src/include/lwip/def.h:
